class programa {
	static button(){
		document.querySelector("#compraPNL_pri").setAttribute("onclick","programa.panelCompra();");
		document.querySelector("#compraPNL_sec").setAttribute("onclick","programa.panelcompraSec();");
		document.querySelector("#compraPNL_ter").setAttribute("onclick","programa.panelCompraTer();");
		document.querySelector("#compraPNL_cua").setAttribute("onclick","programa.panelcompraCua();");
		document.querySelector("#compraPNL_qui").setAttribute("onclick","programa.panelCompraQui();");

	}
	static panelCompra(){
		document.querySelector("#productoPNL").innerHTML =document.querySelector("#producto1").innerHTML;
	}
	static panelcompraSec(){
		console.log("panelcompraSec");
	//	document.querySelector("#productoPNL").innerHTML =document.querySelector("#producto2").innerHTML;
		document.querySelector("#productoPNL").innerHTML =document.querySelector("#producto2").innerHTML;
		
	}
	static panelCompraTer(){
		document.querySelector("#productoPNL").innerHTML =document.querySelector("#producto3").innerHTML;
	}
	static panelcompraCua(){
		document.querySelector("#productoPNL").innerHTML =document.querySelector("#producto4").innerHTML;
	}
	static panelCompraQui(){
		document.querySelector("#productoPNL").innerHTML =document.querySelector("#producto5").innerHTML;
	}
}
programa.button(); 